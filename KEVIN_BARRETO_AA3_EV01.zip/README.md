# Proyecto Spring Boot - Registro de Usuarios

Este proyecto permite registrar usuarios (nombre y correo) usando Spring Boot y Thymeleaf.

## Cómo ejecutar

1. Importa el proyecto en IntelliJ, Eclipse o VS Code.
2. Asegúrate de tener Java y Maven configurados.
3. Ejecuta `ProyectoApplication.java`.
4. Visita `http://localhost:8080` para registrar usuarios.