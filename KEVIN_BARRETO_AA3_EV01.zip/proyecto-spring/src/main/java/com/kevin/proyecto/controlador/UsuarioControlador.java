package com.kevin.proyecto.controlador;

import com.kevin.proyecto.modelo.Usuario;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
public class UsuarioControlador {

    // Lista simulada para guardar usuarios en memoria
    private List<Usuario> usuarios = new ArrayList<>();

    @GetMapping("/")
    public String mostrarFormulario(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "formulario";
    }

    @PostMapping("/registrar")
    public String registrarUsuario(@ModelAttribute Usuario usuario, Model model) {
        usuarios.add(usuario);
        model.addAttribute("usuarios", usuarios);
        return "lista";
    }
}